package com.example.finalexam;

import com.example.finalexam.controllers.StudentController;
import com.example.finalexam.entities.Student;
import com.example.finalexam.repositories.StudentRepository;
import jakarta.servlet.http.HttpSession;
import java.util.Date;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;

class StudentControllerTest {
    @InjectMocks
    private StudentController studentController;
    @Mock
    private StudentRepository studentRepository;
    @Mock
    private Model model;
    @Mock
    private ModelMap modelMap;
    @Mock
    private BindingResult bindingResult;
    @Mock
    private HttpSession session;

    @Test
    void testSaveStudentSuccessfully() {
        try {
            Student student = new Student((Long)null, "John Doe","CSIS 1175",3,"C");
            Mockito.when(this.bindingResult.hasErrors()).thenReturn(false);
            String result = this.studentController.save(this.model, student, this.bindingResult, this.modelMap, this.session);
            ((StudentRepository)Mockito.verify(this.studentRepository, Mockito.times(1))).save(student);
            Assertions.assertEquals("redirect:index", result);
            System.out.println("testSaveCustomerSuccessfully: PASS");
        } catch (Exception | AssertionError e) {
            System.out.println("testSaveCustomerSuccessfully: FAIL - " + ((Throwable)e).getMessage());
        }

    }

    @Test
    void testSaveStudentValidationError() {
        try {
            Student student = new Student();
            Mockito.when(this.bindingResult.hasErrors()).thenReturn(true);
            String result = this.studentController.save(this.model, student, this.bindingResult, this.modelMap, this.session);
            ((StudentRepository)Mockito.verify(this.studentRepository, Mockito.never())).save((Student)Mockito.any());
            Assertions.assertEquals("students", result);
            System.out.println("testSaveCustomerValidationError: PASS");
        } catch (Exception | AssertionError e) {
            System.out.println("testSaveCustomerValidationError: FAIL - " + ((Throwable)e).getMessage());
        }

    }}