package com.example.finalexam;

import com.example.finalexam.entities.Student;
import com.example.finalexam.repositories.StudentRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.Date;

@SpringBootApplication
public class FinalExamApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinalExamApplication.class, args);
	}

	@Bean
	CommandLineRunner commandLineRunner(StudentRepository studentRepository) {
		return args -> {
			studentRepository.save(new Student(null, "John Doe","CSIS 1175",3,"C"));
			studentRepository.save(new Student(null, "Jane","CSIS 2175",3,"A"));
			studentRepository.save(new Student(null, "Doe","CSIS 3175",3,"B"));
			studentRepository.findAll().forEach(p->System.out.println(p.getStudentName()));

		};
	}
}
